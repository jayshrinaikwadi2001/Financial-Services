//base url for all a api call
const baseUrl = "http://localhost:8000";

export { baseUrl };
