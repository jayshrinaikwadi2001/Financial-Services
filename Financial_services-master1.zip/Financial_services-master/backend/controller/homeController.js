const home = (req, res) => {
  return res.send("check this connections");
};

module.exports = {
  home,
};
